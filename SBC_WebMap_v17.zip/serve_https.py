import http.server
import ssl
import os
import socket
import datetime

# Configuration
PORT = 8443
CERT_FILE = "localhost.pem"

def generate_self_signed_cert():
    """Generates a self-signed certificate using the cryptography library."""
    if os.path.exists(CERT_FILE):
        return

    print("Generating self-signed certificate...")
    try:
        from cryptography import x509
        from cryptography.x509.oid import NameOID
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.primitives import serialization
        
        # Generate Key
        key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )
        
        # Generate Cert
        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, u"localhost"),
        ])
        
        cert = x509.CertificateBuilder().subject_name(
            subject
        ).issuer_name(
            issuer
        ).public_key(
            key.public_key()
        ).serial_number(
            x509.random_serial_number()
        ).not_valid_before(
            datetime.datetime.utcnow()
        ).not_valid_after(
            # Valid for 1 year
            datetime.datetime.utcnow() + datetime.timedelta(days=365)
        ).add_extension(
            x509.SubjectAlternativeName([x509.DNSName(u"localhost")]),
            critical=False,
        ).sign(key, hashes.SHA256())
        
        # Write to file (PEM format)
        with open(CERT_FILE, "wb") as f:
            f.write(key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption(),
            ))
            f.write(cert.public_bytes(serialization.Encoding.PEM))
            
        print(f"Certificate generated: {CERT_FILE}")
            
    except ImportError:
        print("\nCRITICAL ERROR: 'cryptography' library is missing.")
        print("The batch file should have installed it. Please run: pip install cryptography\n")
        raise
    except Exception as e:
        print(f"Error generating cert: {e}")

def run_server():
    server_address = ('0.0.0.0', PORT)
    httpd = http.server.HTTPServer(server_address, http.server.SimpleHTTPRequestHandler)
    
    # Create SSL Context
    if os.path.exists(CERT_FILE):
        print(f"Using certificate: {CERT_FILE}")
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(certfile=CERT_FILE)
        httpd.socket = context.wrap_socket(httpd.socket, server_side=True)
    else:
        print("ERROR: Certificate file creation failed.")
        return

    # Get Local IP
    hostname = socket.gethostname()
    local_ip = socket.gethostbyname(hostname)
    
    print(f"\nServing HTTPS on port {PORT}")
    print(f"Local:   https://localhost:{PORT}")
    print(f"Network: https://{local_ip}:{PORT}")
    print("\nNote: You will see a security warning in the browser (Self-Signed Cert).")
    print("Click 'Advanced' -> 'Proceed' (Chrome) or 'Accept Risk' (Firefox).\n")
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")

if __name__ == '__main__':
    # Change into 'app' directory
    if os.path.isdir("app"):
        os.chdir("app")
        
    generate_self_signed_cert()
    run_server()
